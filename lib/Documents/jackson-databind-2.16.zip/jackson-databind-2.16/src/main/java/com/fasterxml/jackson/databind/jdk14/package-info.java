/**
Contains helper class(es) needed to support some of JDK14+
features without requiring running or building using JDK 14.
*/

package com.fasterxml.jackson.databind.jdk14;
