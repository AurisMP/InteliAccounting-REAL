/**
 * Classes needed for JSON schema support (currently just ability
 * to generate schemas using serialization part of data mapping)
 */
package com.fasterxml.jackson.databind.jsonschema;
