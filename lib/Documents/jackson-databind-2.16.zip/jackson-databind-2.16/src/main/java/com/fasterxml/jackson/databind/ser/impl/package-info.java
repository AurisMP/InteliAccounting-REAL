/**
 * Contains implementation classes of serialization part of
 * data binding.
 */
package com.fasterxml.jackson.databind.ser.impl;
