/**
 * Package for some of {@link com.fasterxml.jackson.core.JsonProcessingException}
 * subtypes contained by streaming API.
 */
package com.fasterxml.jackson.core.exc;
